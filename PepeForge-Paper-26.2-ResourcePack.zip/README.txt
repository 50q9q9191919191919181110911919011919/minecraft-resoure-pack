PepeForge weapons converted for Paper/Spigot

This pack uses minecraft:custom_model_data strings.
Example:
/give @s minecraft:diamond_sword[minecraft:custom_model_data={strings:["katana"]}]

Weapon IDs:
katana
iron_greatsword
diamond_greatsword
netherite_greatsword
iron_scythe
diamond_scythe
netherite_scythe
iron_wind_blade
diamond_wind_blade
netherite_wind_blade
crimson_sword
throwing_knife
chisel
anchor
crescent_spear
crescent_bow
solar_shield_0
solar_shield_1
solar_shield_2
solar_shield_3

The resource pack changes appearance only. It does not add custom damage, abilities, recipes, or combat behavior.
Bedrock players through Geyser will need a separate Bedrock resource pack for equivalent models.
